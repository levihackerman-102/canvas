"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { WorkflowCanvas } from "@/components/workflow-canvas"
import { BlockPalette } from "@/components/block-palette"
import { WorkflowSettings } from "@/components/workflow-settings"
import { Share, Download, Code, Zap } from "lucide-react"

export function WorkflowBuilder() {
  const [activeWorkflow, setActiveWorkflow] = useState<string | null>(null)
  const [selectedBlock, setSelectedBlock] = useState<string | null>(null)

  const exportWorkflow = () => {
    console.log("[v0] Exporting workflow configuration")
    const workflowData = {
      name: "My Auction Workflow",
      version: "1.0.0",
      blocks: [], // This would come from canvas state
      connections: [],
      settings: {},
      timestamp: new Date().toISOString(),
    }

    const blob = new Blob([JSON.stringify(workflowData, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "auction-workflow.json"
    a.click()
    URL.revokeObjectURL(url)
  }

  const generateCode = () => {
    console.log("[v0] Generating integration code")
    alert("Integration code generated! Check the console for API endpoints and webhook configurations.")
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[calc(100vh-200px)]">
      {/* Block Palette */}
      <div className="lg:col-span-1">
        <Card className="h-full">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg">Workflow Blocks</CardTitle>
            <p className="text-xs text-muted-foreground">Drag blocks to canvas to build your workflow</p>
          </CardHeader>
          <CardContent className="p-0">
            <BlockPalette />
          </CardContent>
        </Card>
      </div>

      {/* Main Canvas */}
      <div className="lg:col-span-2">
        <Card className="h-full">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <CardTitle className="text-lg">Workflow Canvas</CardTitle>
                {activeWorkflow && <Badge variant="secondary">{activeWorkflow}</Badge>}
              </div>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="sm" onClick={exportWorkflow}>
                  <Download className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="sm" onClick={generateCode}>
                  <Code className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Share className="w-4 h-4" />
                </Button>
                <Button size="sm">
                  <Zap className="w-4 h-4 mr-2" />
                  Deploy
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0 h-[calc(100%-80px)]">
            <WorkflowCanvas />
          </CardContent>
        </Card>
      </div>

      {/* Settings Panel */}
      <div className="lg:col-span-1">
        <Card className="h-full">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg">Configuration</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="workflow" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="workflow">Workflow</TabsTrigger>
                <TabsTrigger value="block">Block</TabsTrigger>
                <TabsTrigger value="deploy">Deploy</TabsTrigger>
              </TabsList>
              <TabsContent value="workflow" className="mt-4">
                <WorkflowSettings />
              </TabsContent>
              <TabsContent value="block" className="mt-4">
                {selectedBlock ? (
                  <div className="space-y-4">
                    <h4 className="text-sm font-medium">Block Configuration</h4>
                    <div className="text-sm text-muted-foreground">Configure settings for the selected block</div>
                  </div>
                ) : (
                  <div className="text-sm text-muted-foreground">
                    Select a block on the canvas to configure its settings
                  </div>
                )}
              </TabsContent>
              <TabsContent value="deploy" className="mt-4">
                <div className="space-y-4">
                  <h4 className="text-sm font-medium">Deployment Options</h4>
                  <div className="space-y-3">
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={exportWorkflow}
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Export Configuration
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start bg-transparent"
                      onClick={generateCode}
                    >
                      <Code className="w-4 h-4 mr-2" />
                      Generate API Code
                    </Button>
                    <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                      <Share className="w-4 h-4 mr-2" />
                      Webhook URLs
                    </Button>
                  </div>
                  <div className="text-xs text-muted-foreground mt-4">
                    Deploy your workflow to start processing auctions automatically
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
