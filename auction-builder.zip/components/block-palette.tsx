"use client"

import { Card } from "@/components/ui/card"
import { Package, Play, DollarSign, Clock, CheckCircle, RefreshCw, Mail, Gavel, Shield, Zap } from "lucide-react"

const blockCategories = [
  {
    name: "Auction Blocks",
    blocks: [
      {
        id: "list-item",
        name: "List Item",
        description: "Define auction item details",
        icon: Package,
        color: "bg-blue-500/20 text-blue-400 border-blue-500/30",
      },
      {
        id: "start-auction",
        name: "Start Auction",
        description: "Launch auction instance",
        icon: Play,
        color: "bg-green-500/20 text-green-400 border-green-500/30",
      },
      {
        id: "accept-bid",
        name: "Accept Bid",
        description: "Process incoming bids",
        icon: Gavel,
        color: "bg-purple-500/20 text-purple-400 border-purple-500/30",
      },
      {
        id: "end-auction",
        name: "End Auction",
        description: "Close auction manually or automatically",
        icon: Clock,
        color: "bg-orange-500/20 text-orange-400 border-orange-500/30",
      },
    ],
  },
  {
    name: "Payment Blocks",
    blocks: [
      {
        id: "escrow-payment",
        name: "Escrow Payment",
        description: "Secure bid funds via RedotPay",
        icon: Shield,
        color: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
      },
      {
        id: "release-payment",
        name: "Release Payment",
        description: "Transfer winning funds to merchant",
        icon: DollarSign,
        color: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
      },
      {
        id: "refund-payment",
        name: "Refund Payment",
        description: "Return funds to losing bidders",
        icon: RefreshCw,
        color: "bg-red-500/20 text-red-400 border-red-500/30",
      },
    ],
  },
  {
    name: "Automation Blocks",
    blocks: [
      {
        id: "settlement",
        name: "Auto Settlement",
        description: "Automated winner selection and payment",
        icon: Zap,
        color: "bg-indigo-500/20 text-indigo-400 border-indigo-500/30",
      },
      {
        id: "notification",
        name: "Notification",
        description: "Send email/SMS updates",
        icon: Mail,
        color: "bg-pink-500/20 text-pink-400 border-pink-500/30",
      },
      {
        id: "validation",
        name: "Validation",
        description: "Verify bid conditions",
        icon: CheckCircle,
        color: "bg-teal-500/20 text-teal-400 border-teal-500/30",
      },
    ],
  },
]

export function BlockPalette() {
  return (
    <div className="space-y-6 p-4">
      {blockCategories.map((category) => (
        <div key={category.name}>
          <h3 className="text-sm font-medium text-muted-foreground mb-3">{category.name}</h3>
          <div className="space-y-2">
            {category.blocks.map((block) => (
              <Card
                key={block.id}
                className={`p-3 cursor-pointer hover:bg-accent/50 transition-colors border ${block.color}`}
                draggable
                onDragStart={(e) => {
                  e.dataTransfer.setData("application/json", JSON.stringify(block))
                }}
              >
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">
                    <block.icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-medium">{block.name}</span>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">{block.description}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}
